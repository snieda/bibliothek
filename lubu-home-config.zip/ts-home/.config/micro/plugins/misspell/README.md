# Misspell Plugin for Micro

This repository holds the misspell plugin for micro.

Install with `> plugin install misspell`. This plugin will lint text
for spelling mistakes.
